<h1 align="center">To Do List</h1>

<p align="center">Build with Javascript, CSS, HTML</p>
<p>Learning Objective: To get comfortable with Javascript's events and Document Object Model (DOM)</p>
<p>Website Link 👇 </p> 
<a href="https://todolistweb.vercel.app/" >To-Do-List</a>
